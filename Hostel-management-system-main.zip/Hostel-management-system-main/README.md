# Hostel-management-system
It is a module driven project that lets the admin monitor the rooms in the hostel, add rooms, delete rooms, allocate rooms, add student  ,delete student and many more options will be provided.
